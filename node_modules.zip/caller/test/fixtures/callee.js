'use strict';

module.exports = function (caller) {
    return caller();
};