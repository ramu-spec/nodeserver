'use strict';

var caller = require('../../');

console.log(caller());
module.exports = caller();