
2.0.1 / 2013-08-23
==================

 - package: add "component" section

2.0.0 / 2013-08-22
==================

 - No more function invocation required, returns `global` directly

1.0.0 / 2013-08-22
==================

 - Initial release
