
# global

  Returns a reference to the `global` object

## Installation

  Install with [component(1)](http://component.io):

    $ component install component/global

## API

``` js
var global = require('global');
```

## License

  MIT
