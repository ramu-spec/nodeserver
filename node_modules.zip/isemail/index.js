module.exports = require('./lib/isemail');
