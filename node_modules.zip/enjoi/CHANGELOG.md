### v1.0.4

* when undefined `minLength` should default to 0.

### v1.0.3

* Validate when `additionalProperties` is boolean.

### v1.0.2

* Support for `oneOf`.

### v1.0.1

* Support for `format` in string types.

### v1.0.0

* [BREAKING] `subSchemas` is now passed as a property in `options`.
* Support for custom types using `options.types`.
