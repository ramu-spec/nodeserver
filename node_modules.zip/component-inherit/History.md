
0.0.2 / 2012-09-03 
==================

  * fix typo in package.json
