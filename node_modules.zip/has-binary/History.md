
0.1.5 / 2014-09-04
==================

 * prevent browserify from bundling `Buffer`
