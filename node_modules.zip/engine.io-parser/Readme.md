
# engine.io-parser

[![Build Status](https://secure.travis-ci.org/Automattic/engine.io-parser.svg)](http://travis-ci.org/Automattic/engine.io-parser)
[![NPM version](https://badge.fury.io/js/engine.io-parser.svg)](http://badge.fury.io/js/engine.io-parser)

This is the JavaScript parser for the engine.io protocol encoding,
shared by both
[engine.io-client](https://github.com/Automattic/engine.io-client) and
[engine.io](https://github.com/Automattic/engine.io).

## License

MIT
